# CryptoHash

Functions to be used for hashing of cryptocurrency 